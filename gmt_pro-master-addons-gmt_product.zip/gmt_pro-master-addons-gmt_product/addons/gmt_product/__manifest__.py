
{
    'name': 'GMT Machines Online',
    'version': '1.0',
    'category': 'Tools',
    'summary': 'machines and  equipment management',
    'depends': ["product","stock","base","sale","account"],
    'data': [
        'view/gmt.xml',

        'view/services.xml',
        'view/amc.xml',
        'view/amt_package.xml',
        'view/masters.xml',
        'reports/sale_order.xml',
        'view/warrenty_master.xml',
        'view/account_move.xml',
        'reports/report.xml',
        'view/product_product.xml',
        'security/service_security.xml',
        'security/ir.model.access.csv',
        'view/seq.xml',
        'view/res_compnay.xml',
        'view/sale_confirm_form.xml',
        'reports/custom_invoice_pdf.xml',
        'reports/view.xml',
        "view/fav.xml",
        'reports/sale_acceptance_form.xml',
        'reports/proforma_invoice.xml',
        
        
    ],

    'installable': True,
    'auto_install': False,
    'application': True,
}