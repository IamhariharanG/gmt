from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz

class ProductAccountLine(models.Model):
    _inherit = 'account.move.line'
    
    brand = fields.Many2one('brand.brand',string='Brand')
    # model = fields.Many2one("product.template.attribute.value", string='Model', help='Select Model', ondelete='restrict')
    number=fields.Char(string="Serial No")
    packagename=fields.Char(string='Package Name')
    service_seq = fields.Char(string='Service No')
    tax_value = fields.Float(string="Tax Value",compute='gtax_val',store=True)
    
    @api.depends('tax_ids')
    def gtax_val(self):
        for rec in self:
            rec.tax_value = rec.tax_ids.amount*rec.price_subtotal/100

class ProductAccountMove(models.Model):
    _inherit = 'account.move'
    
    tax_value = fields.Float(string="Tax Value",compute='_tax_value',store=True)
    
    @api.depends('invoice_line_ids')
    def _tax_value(self):
        for rec in self:
            tax=[]
            for line in rec.invoice_line_ids:
                tax.append(line.tax_value)
            rec.tax_value = sum(tax)
                