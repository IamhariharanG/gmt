from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz



class AMC(models.Model):
	_name = 'amc.amc'
	_rec_name='number'

	name = fields.Many2one('res.partner',string='Customer Name', required=True,domain = "[('user_ids','=',False)]")
	brand = fields.Many2one('brand.brand',string='Brand')
	productcategory=fields.Many2one('product.category',string="Product Category")
	productname=fields.Many2one('product.template',string="Product Name",domain = "[('brand_name','=',brand)]")
	# model = fields.Many2one("product.template.attribute.value", string='Model', help='Select Model', ondelete='restrict',domain = "[('product_tmpl_id','=',productname)]")
	product_id = fields.Many2one("product.product", string='Model',domain = "[('product_tmpl_id','=',productname)]")
	
	number=fields.Char(string="Serial No")
	packagename=fields.Many2one('amcpackage.amcpackage',string='Package Name',domain = "[('productname','=',productname)]")
	preventive = fields.Integer(string='Preventive(onsite) Maintenance',compute='_compute_Preventive')
	breakdown = fields.Integer(string='Breakdown(InHouse)',compute='_compute_Breakdown')
	totalmaintenance=fields.Float(string='Total Maintenance',compute='_compute_total')
	price = fields.Integer(string='Price')


	@api.depends('preventive', 'breakdown')
	def _compute_total(self):
		for record in self:
			record.totalmaintenance = record.preventive + record.breakdown

	@api.depends('preventive')
	def _compute_Preventive(self):
		for record in self:
			record.preventive = record.packagename.preventive

	@api.depends('breakdown')
	def _compute_Breakdown(self):
		for record in self:
			record.breakdown = record.packagename.breakdown

	@api.onchange('packagename')
	def _onchange_packagename(self):
		self.breakdown = self.packagename.breakdown
		self.preventive = self.packagename.preventive
		self.price = self.packagename.price

	# @api.onchange('productname')
	# def _onchange_productname(self):
	# 	return {'domain': {'product_id': [('product_tmpl_id','=',self.productname.id)]}}

	# @api.onchange('productname')
	# def _onchange_product_domain(self):
	# 	return {'domain': {'packagename': [('productname','=',self.productname.id)]}}

	# @api.onchange('brand')
	# def _onchange_brand_domain(self):
	# 	return {'domain': {'productname': [('brand_name','=',self.brand.id)]}}
