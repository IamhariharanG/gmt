from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz

class AMCadd(models.Model):
	_name = 'amcpackage.amcpackage'
	_rec_name='packagename'

	productname=fields.Many2one('product.template',string="Product Name", required=True)
	productage=fields.Char(string="Product Age", required=True)
	packagename=fields.Char(string="Package Name", required=True,compute='_compute_packagename')
	gender = fields.Selection([('with_spare', 'With Spare'), ('with_out_spare', 'With Out Spare')], string='packagetype', required=True)
	preventive = fields.Integer(string='Preventive(onsite) Maintenance')
	breakdown = fields.Integer(string='Breakdown(InHouse)')
	totalmaintenance=fields.Float(string='Total Maintenance',compute='_compute_total')
	price = fields.Integer(string='Price')

	@api.depends('preventive', 'breakdown')
	def _compute_total(self):
		for record in self:
			record.totalmaintenance = record.preventive +  record.breakdown

	@api.depends('packagename','productage','gender')
	def _compute_packagename(self):
		for record in self:
			record.packagename = (record.productname.name or '') + ' ' + (record.productage or '') + ' ' + (dict(self._fields['gender'].selection).get(record.gender) or '')

