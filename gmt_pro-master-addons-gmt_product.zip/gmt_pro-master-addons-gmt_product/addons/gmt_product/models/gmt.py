from odoo import fields, models

from inspect import signature
from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from dateutil.relativedelta import relativedelta 
from openerp.exceptions import ValidationError


class ProductTemplates(models.Model):
    _inherit = 'product.template'

    gmt_val_details=fields.One2many('gmt.table.line','gmt_dataval',string="GMT Table")  
    templ_model_name = fields.Char("Model")
    # products_optional = fields.Many2one("product.product",string="Optional Products")
    
    @api.constrains('attribute_line_ids','name')
    def product_attribute_name(self):
        for rec in self.product_variant_ids:
            if rec.product_template_attribute_value_ids:
                attributes = "" 
                for value in rec.product_template_attribute_value_ids:
                    attributes = attributes + value.name + " , "

                rec.model_name = attributes[:-2]
                rec.product_display = rec.display_name
            else:
                rec.product_display = rec.display_name
                rec.model_name = ''
    
class SpecificationFunctions(models.Model):
    _name='gmt.table.line'
    
    gmt_dataval=fields.Many2one('product.template',string='GMT Val')
    
    functions=fields.Many2one('function.table.line','Functions')
    item_no = fields.Many2one('item.table.line','Item Number')
    value = fields.Many2many('value.table.line',string='Value',store=True)
    
    
class functionspecific(models.Model):
    _name = 'function.table.line'
    _rec_name = 'name'

    name = fields.Char('Name')
    
class Itempecific(models.Model):
    _name = 'item.table.line'
    _rec_name = 'name'

    name = fields.Char('Name')
    
class Valuespecific(models.Model):
    _name = 'value.table.line'
    _rec_name = 'name'
    
    name = fields.Char('Name')
  

class saleGMT(models.Model):
    _inherit = 'sale.order'
    
    gmt_val_sale=fields.One2many('sale.data.line','gmt_datasale',string="GMT Sale")
    terms_conditions = fields.Many2one('terms.conditions',"Terms and Conditions")
    # usd_int_terms = fields.Html("")
    title = fields.Selection([('mr',"Mr. "),('mrs',"Mrs. "),('ms',"Ms. ")],string="Title",default='mr')
    
    tcs_applied = fields.Boolean("Tcs Amount Applied",compute='tcs_amount_calculate',store=True)
    tcs_amount = fields.Float("TCS @ 0.1%",compute="tcs_amount_calculate",store=True)
    
    proforma_sent = fields.Selection([('proforma_sent',"Proforma Sent"),
                                        ('proforma_not_sent',"Proforma Not Sent")
                                        ],string="Proforma Details",default="proforma_not_sent")
    proforma_no = fields.Char("Proforma Invoice No.")
    mail_send_status = fields.Selection([('sent',"Mail Sent"),('not_sent',"Mail Not Sent")],string="Mail Status")
    mail_failed_reason = fields.Char("Mail Failure Reason")
        
    def action_quotation_send(self):
        res = super(saleGMT, self).action_quotation_send()

        if self.env.context.get('proforma') == True:
            self.proforma_sent = 'proforma_sent'
        else:
            pass
        return res
    
    @api.depends("amount_total","order_line")
    def tcs_amount_calculate(self):
        for rec in self:
            year = datetime.now().year
            start_date = datetime(year, 1, 1, 0, 0, 0)
            end_date = datetime(year, 12, 31, 23, 59, 59)

            current_year_sale_data = self.env['sale.order'].search([("state",'=','sale'),
                                                                    ('date_order', '>=', start_date),
                                                                    ('date_order', '<=', end_date),
                                                                    ('partner_id','=',rec.partner_id.id)])   

            total_amount = sum(current_year_sale_data.mapped(lambda order: order.amount_total))

            overall_total = total_amount + rec.amount_total


            if overall_total >= 5000000:
                rec.tcs_amount = (rec.amount_untaxed+rec.amount_tax)*0.1/100
                rec.amount_total = rec.amount_untaxed+rec.amount_tax + rec.tcs_amount
                rec.tcs_applied = True   
                
            else:
                rec.tcs_amount = 0
                rec.tcs_applied = False
    
    
    @api.onchange('terms_conditions')
    def _termscondition(self):
        for rec in self:
            rec.usd_int_terms = rec.terms_conditions.terms
    @api.model
    def create(self, values):
        result = super(saleGMT, self).create(values)
        result.name = f"{'GMT-QTN'}{'-'}{self.env['ir.sequence'].next_by_code('new.sequence.order')}{'/'}{datetime.now().year}"
        result.proforma_no = result.name.replace("QTN", "PINV")
        return result
    
    @api.model
    def write(self, values):       
        for rec in self:
            attachments = self.env['ir.attachment'].search([('res_model','=','sale.order'),('public','=',True)])
            if attachments:
                for data in attachments:
                    data.public = False
        return super(saleGMT, self).write(values)  


    def action_send_email(self):
        mail_template = self.env.ref('gmt_product.email_template')
        mail_template.send_mail(self.id, force_send=True)
   
   
    def action_send_email(self):
        
        '''This function opens a window to compose an email, with the emai template message loaded by default'''
        
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']

        try:
            template_id = ir_model_data.get_object_reference('gmt_product', 'email_template')[1]
            template = self.env['mail.template'].search([('id','=',template_id)])
            ir_id=[]
            
            for ir_data in self.user_id.partner_id.digital_card:
                if ir_data.id not in ir_id:
                    ir_id.append(ir_data.id)
        
            for rec in self.gmt_val_sale.product_attachment:
                if rec.id not in ir_id:
                    ir_id.append(rec.id) 

            if ir_id:
                template.attachment_ids = ir_id
            else:
                template.attachment_ids = [(5,0,0)]
            
        except ValueError:
            template_id = False
            
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
            
        ctx = {
            'default_model': 'sale.order',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
        }
        
        self.mail_send_status = 'sent'
        
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        }  
    
    @api.onchange('order_line')
    def product_data(self):
        for rec in self:
            product=[(5,0,0)]
            for line in rec.order_line:
                data={
                    'product_id':line.product_id.id,
                }
                product.append((0,0,data))
            rec.gmt_val_sale = product
    
    
    def get_sale_confirm_form(self):
        product = ""
        for line in self.order_line:
            if line.product_id.model_name:
                product = product + line.product_id.model_name + " , "
        
        return {
            'type': 'ir.actions.act_window',
            'name': 'Sale Confirm Form',
            'view_mode': 'tree,form',
            'res_model': 'sale.confirm.form',
            'domain': [('sale_order', '=', self.id)],
            'context': {'default_sale_order':self.id,
                        'default_company_name':self.partner_id.parent_id.id,
                        'default_total':self.amount_total,
                        'default_tcs': self.tcs_amount,
                        'default_gst':self.amount_tax,
                        'default_person_name':self.user_id.id,
                        'default_price_usd':self.amount_untaxed,
                        'default_machines_ordered':product[:-3],
                        'default_partner_id':self.partner_id.id}
                }
    
    
class GMTsale(models.Model):
    _name='sale.data.line'
    
    gmt_datasale=fields.Many2one('sale.order',string='GMT sale')
    
    product_id=fields.Many2one('product.product',string='Product Name')
    product_attachment = fields.Many2many(comodel_name='ir.attachment',column_1='attach1',relation="m2m_ir_identity_card_rel",column_2='attach2',string='Products Attachments',compute='_attachment_data',store=True)
    
    
    @api.depends('product_id')
    def _attachment_data(self):
        for rec in self:
            rec.product_attachment = rec.product_id.website_attachment_ids

class SaleOrderLines(models.Model):
    _inherit = 'sale.order.line'

    sequence_ref = fields.Integer('SL.NO', compute="_sequence_ref")
    desription_done = fields.Boolean('Description Done',compute='_product_description',store=True)
    profoma_product = fields.Boolean("Proforma Product",default=True)
    updated_qty = fields.Float("Updated Qty")
    extra_desc = fields.Text("Extra Description")

    @api.onchange('product_uom')
    def _onchange_order_line(self):
        uom_default = self.env['uom.uom'].search([('name', '=', 'No.')], limit=1)
        if uom_default:
            self.product_uom = uom_default.id

    @api.onchange("product_uom_qty")
    def _qty_update(self):
        for rec in self:
            if rec.product_uom_qty:
                rec.updated_qty = rec.product_uom_qty
            

    @api.onchange("profoma_product")
    def _proforma_update(self):
        for rec in self:
            if rec.profoma_product == False:
                rec.product_uom_qty = 0
            else:
                rec.product_uom_qty = rec.updated_qty


    @api.depends('order_id.order_line')
    def _sequence_ref(self):
        for line in self:
            no = 0
            line.sequence_ref = no
            for l in line.order_id.order_line:
                no += 1
                l.sequence_ref = no
                
                
    @api.depends("product_id")
    def _product_description(self):
        for rec in self:
            if rec.product_id.sales_description:
                rec.name = rec.product_id.sales_description
            else:
                pass

            if rec.extra_desc:
                rec.name = rec.extra_desc

            rec.desription_done = True
            
    
    @api.onchange("name")
    def _onchange_description(self):
        if self.name:
            self.extra_desc = self.name
            

class ProductAttributeValuesData(models.Model):
    _inherit = 'product.attribute'

    @api.constrains('value_ids','name')
    def product_full_name(self):
        if self.product_tmpl_ids:
            for product in self.product_tmpl_ids: 
                for rec in product.product_variant_ids:
                    attributes = "" 
                    for value in rec.product_template_attribute_value_ids:
                        attributes = attributes + value.name + " , "

                    rec.model_name = attributes[:-2]
                    rec.product_display = rec.display_name
                    

class MailMailInherit(models.Model):
    _inherit = 'mail.mail'

    mail_sent_check = fields.Boolean("Mail Send Check",compute="_onchange_mail",store=True)

    @api.depends("state","failure_reason")
    def _onchange_mail(self):
        for rec in self:
            if rec.state == 'exception' and rec.model == 'sale.order':
                sale_orm = self.env['sale.order'].search([('id','=',rec.res_id)],limit=1)
                if sale_orm:
                    sale_orm.mail_send_status = 'not_sent'
                    # sale_orm.mail_failed_reason = rec.failure_reason
                    sale_orm.mail_failed_reason = "Your message exceeded Google's message size limits."

            rec.mail_sent_check = True