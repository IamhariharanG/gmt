from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz


class Brand(models.Model):
    _name = 'brand.brand'

    name = fields.Char(string='Brand Name', required=True)
    
    
class Model(models.Model):
    _name = 'model.model'
    _rec_name = 'name'

    brand_name = fields.Many2one('brand.brand', String="Brand Name",help="Select a model for the part")
    name = fields.Char(string='ModelNo', required=True)


class ItemReceived(models.Model):
    _name = 'itemreceived.itemreceived'
    _rec_name='item'

    item = fields.Char(string='Item', required=True)
    qty = fields.Integer(string='Qty')
    
class TermsConditions(models.Model):
    _name = 'terms.conditions'
    _rec_name = 'conditions'
    
    conditions = fields.Char("Terms and Conditions")
    terms = fields.Html('Terms and Conditions')
    
class favorite_list(models.Model):
    
    _name = 'fav.list'
    _rec_name = 'partner_id'

    partner_id = fields.Many2one('res.partner',string='Partner Name')
    res_users = fields.Many2one('res.users',string="User Name")
    product_id = fields.Many2one('product.template',string='Product')
    product_product_id = fields.Many2one('product.product',string='Product')
    
class ProductVarient(models.Model):
    _inherit = 'product.product'

    favourite_lists = fields.One2many('fav.list','product_product_id',string='Fav List')
    
class ProductTemplates(models.Model):
    _inherit = 'product.template'

    favourite_lists= fields.One2many('fav.list','product_id',string='Fav List')