from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz


class ProductProducts(models.Model):
    _inherit = 'product.product'

    spefication_val_details=fields.One2many('gmt.product.line','product_dataval',string="Product GMT Table")  
    sales_description = fields.Text("Sales Description")
    products_optional = fields.Many2one("product.product",string="Optional Products")
    
    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        args = list(args or [])
        if name :
            args += ['|',  ('name', operator, name), ('product_template_attribute_value_ids', operator, name)]
        return self._search(args, limit=limit, access_rights_uid=name_get_uid)
    
    
    product_display = fields.Char("Product Name")
    model_name = fields.Char("Attribute Name")
    
    @api.model
    def create(self,vals):
        result = super(ProductProducts, self).create(vals)

        for rec in result:
            rec.product_display = rec.display_name

            s_strs = rec.display_name
            data = s_strs.split('(')
            data1 = data[-1]
            
            if data1[-1] == ')':
                word = data1[:-1]
                rec.model_name = word

        return result                    

    
class SpecificationFunctions(models.Model):
    _name='gmt.product.line'
    _rec_name = 'functions'
    
    product_dataval=fields.Many2one('product.product',string='Product GMT Val')
    
    functions=fields.Many2one('function.table.line',string='Specification')
    item_no = fields.Many2one('uom.uom',string='Unit')
    value = fields.Many2many('value.table.line',string='Value',store=True)
    value_item = fields.Char(string='Item Value',store=True)  
    
class crmlead(models.Model):
    _inherit = 'crm.lead'

    product_id = fields.Many2one('product.template',string = 'Product Name')
    industrial_types = fields.Many2one("industrial.master",string="Industrial Types")

    @api.onchange('country_id','state_id')
    def _onchange_country_id(self):
        if not self.country_id:
            country_default = self.env['res.country'].search([('name', '=', 'India')], limit=1)
            if country_default:
                self.country_id = country_default.id
        if not self.state_id:
            state_default = self.env['res.country.state'].search([('name', '=', 'Tamil Nadu')], limit=1)
            if state_default:
                self.state_id = state_default.id

        self.mobile = '+91'