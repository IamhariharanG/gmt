from odoo import fields, models
from inspect import signature
from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from dateutil.relativedelta import relativedelta 
from openerp.exceptions import ValidationError


    
class ResCompanyData(models.Model):
    _inherit='res.company'

    cin_no = fields.Char('CIN No')