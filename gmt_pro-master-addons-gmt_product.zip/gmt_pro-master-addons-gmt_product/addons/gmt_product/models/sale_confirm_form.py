from odoo import fields, models
from inspect import signature
from odoo import api, fields, models, _
from datetime import date,datetime,timedelta
from dateutil.relativedelta import relativedelta 
from openerp.exceptions import ValidationError


class SaleConfirmForm(models.Model):
    _name = 'sale.confirm.form'
    _rec_name = 'sale_order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    person_name = fields.Many2one('res.users',string="SALES PERSON'S NAME",track_visibility='onchange')
    booking_date = fields.Date(string="Date of Order Booking:",track_visibility='onchange',default=datetime.now().strftime('%Y-%m-%d'))
    company_name = fields.Many2one('res.partner',String="NAME OF THE COMPANY",track_visibility='onchange')
    
    owners_partner_val=fields.One2many('owner.partners','sale_form_id',string='Owners/MD/Partner/Proproetor/Directors',track_visibility='onchange')
    management_val=fields.One2many('management.contact','sale_form_id',string='Management Side Contact details',track_visibility='onchange')
    account_val=fields.One2many('payment.contact','sale_form_id',string='Account Side/Payment Side Contact Persons details',track_visibility='onchange')
    delivery_val=fields.One2many('delivery.details','sale_form_id',string='Delivery  Side Contact Persons Details',track_visibility='onchange')
    
    website_id_details= fields.Char("Web Site ID/Customers Nature of work",track_visibility='onchange')
    billing_address = fields.Text("Billing Address of the Company",track_visibility='onchange')
    deliver_address = fields.Text('Delivery Address of the Company',track_visibility='onchange')
    customer_po_no = fields.Char("Customers PO No and Date Or else Sales Order will be considered as Purchase Order",track_visibility='onchange')
    gst_no = fields.Char("GST NO",track_visibility='onchange')
    iec_no = fields.Char("IEC NO",track_visibility='onchange')
    transaction_type = fields.Char("TYPE OF TRANSACTION",track_visibility='onchange')
    machines_ordered = fields.Char("MACHINES ORDERED",track_visibility='onchange')
    accessories = fields.Char("Accessories or any special instruction",track_visibility='onchange')
    price_usd = fields.Float("PRICE IN INR ",track_visibility='onchange')
    gst = fields.Float("GST @ 18%",track_visibility='onchange')
    
    tcs = fields.Float("TCS @ 0.1%",track_visibility='onchange')
    
    total = fields.Float("TOTAL",track_visibility='onchange')
    payment_terms = fields.Char("TERMS OF PAYMENT",track_visibility='onchange')
    advance = fields.Float("ADVANCE",track_visibility='onchange')
    balance = fields.Float("Balance",track_visibility='onchange')
    # bolster = fields.Char("BOLSTER / SLIDE / PUNCH & DIE APPROVED",track_visibility='onchange')

    punch_cusomer_approved = fields.Selection([('yes',"Yes"),('no',"No")],string = "APPROVED BY CUSTOMER")
    punch_customer_attachment = fields.Selection([('yes',"Yes"),('no',"No")],
                                                 string = "CUSTOMER APPROVED DRAWING ATTACHED ALONG WITH SALES ORDER")
    
    bolstar_cusomer_approved = fields.Selection([('yes',"Yes"),('no',"No")],string = "APPROVED BY CUSTOMER")
    bolstar_customer_attachment = fields.Selection([('yes',"Yes"),('no',"No")],
                                                   string = "CUSTOMER APPROVED DRAWING ATTACHED ALONG WITH SALES ORDER")
        
    dispatch_date = fields.Date("DESPATCH DATE PROMISED",track_visibility='onchange')
    delivery_date = fields.Date("DELIVERY DATE PROMISED",track_visibility='onchange')
    liner_fix_by = fields.Char("LINER FIX BY",track_visibility='onchange')
    liner_payment = fields.Char("Payment",track_visibility='onchange')
    cf_agent_by = fields.Char("C&F AGENT BY",track_visibility='onchange')
    cf_payment = fields.Char("Payment",track_visibility='onchange')
    lorry_fix_by = fields.Char("LORRY FIX BY",track_visibility='onchange')
    local_payment = fields.Char("Payment",track_visibility='onchange')
    special_instruction = fields.Text('SPECIAL INSTRUCTIONS : 1',track_visibility='onchange',default="Storage of machinery in case delivery cannot be taken by Customer: The maximum time limit for clearance of materials is 24 hours.  On information of arrival of machine by email after such time depending upon the size and nature of machine, factors such as storage, loading, unloading charges and securing the machine against natural elements to maintain its originality as much as possible will be necessitated involving cost which the customer will have to bear")

    se_name = fields.Char("1. Sales Engineer Name",track_visibility='onchange')
    acceptance_form_no = fields.Char("2.  My Order Acceptance Form No",track_visibility='onchange')
    acceptance_date = fields.Date("3.  My Order Acceptance Form Dated",track_visibility='onchange',default=datetime.now().strftime('%Y-%m-%d'))
    customer_name = fields.Char("4.  Customer Name",track_visibility='onchange')
    machine_order_name = fields.Char("5.  Machine Ordered for ",track_visibility='onchange')
    commitment_customer = fields.Text("6. Commitment of the Customer for delivery is : ",track_visibility='onchange')
    
    text_content = fields.Text('Text',track_visibility='onchange',default='I hereby confirm No discounts/offers/commitments are offerd to customer and the OAF is valid as is wherein, further I have informed the customer of the payment procedure of LC / "C" form requirements.')

    sale_order = fields.Many2one('sale.order',string="Sale Order", required=True,track_visibility='onchange')
    extra_text = fields.Text("Description")
    
    partner_id = fields.Many2one('res.partner',string="Customer Name")

    @api.onchange("total","price_usd",'advance')
    def _total_amount_gst(self):
        for rec in self:
            
            if rec.price_usd:
                rec.gst = rec.price_usd * 18 / 100
                rec.total = rec.price_usd + rec.gst
                
            if rec.total > 5000000:
                rec.tcs = rec.total * 0.1 / 100
                rec.total = rec.price_usd + rec.gst + rec.tcs 
                rec.balance = rec.total - rec.advance
            else:
                rec.tcs = 0
                rec.total = rec.price_usd + rec.gst + rec.tcs 
                rec.balance = rec.total - rec.advance


    @api.model
    def create(self,vals):
        result = super(SaleConfirmForm, self).create(vals)
        
        result.acceptance_form_no= f"{self.env['ir.sequence'].next_by_code('acceptance.sequence')}"
            
        return result
    
    
    def action_sale_confirm_email(self):
        mail_template = self.env.ref('gmt_product.email_template_sale_confirm_form')
        mail_template.send_mail(self.id, force_send=True)
   
   
    def action_sale_confirm_email(self):
        
        '''This function opens a window to compose an email, with the emai template message loaded by default'''
        
        self.ensure_one()
        ir_model_data = self.env['ir.model.data']

        try:
            template_id = ir_model_data.get_object_reference('gmt_product', 'email_template_sale_confirm_form')[1]
        except ValueError:
            template_id = False
            
        try:
            compose_form_id = ir_model_data.get_object_reference('mail', 'email_compose_message_wizard_form')[1]
        except ValueError:
            compose_form_id = False
            
        ctx = {
            'default_model': 'sale.confirm.form',
            'default_res_id': self.ids[0],
            'default_use_template': bool(template_id),
            'default_template_id': template_id,
            'default_composition_mode': 'comment',
            'mark_so_as_sent': True,
        }
        
        return {
            'name': _('Compose Email'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'target': 'new',
            'context': ctx,
        } 
    

class OwnersPartners(models.Model):
    _name = 'owner.partners'
    
    sale_form_id = fields.Many2one('sale.confirm.form', String="Owners/MD/Partner/Proproetor/Directors")
    
    name = fields.Char("Name")
    birthday = fields.Date("Birthday")
    email = fields.Char("Email ID")
    designation = fields.Char("Designation")
    cell_no = fields.Char("Cell No/Ph No")
    
class ManagementContact(models.Model):
    _name = 'management.contact'
    
    sale_form_id = fields.Many2one('sale.confirm.form', String="Management Side Contact details")
    
    name = fields.Char("Name")
    birthday = fields.Date("Birthday")
    email = fields.Char("Email ID")
    designation = fields.Char("Designation")
    cell_no = fields.Char("Cell No/Ph No")

class PaymentContact(models.Model):
    _name = 'payment.contact'

    sale_form_id = fields.Many2one('sale.confirm.form', String="Account Side/Payment Side Contact Persons details")

    name = fields.Char("Name")
    birthday = fields.Date("Birthday")
    email = fields.Char("Email ID")
    designation = fields.Char("Designation")
    cell_no = fields.Char("Cell No/Ph No")
    
class DeliveryDetails(models.Model):
    _name = 'delivery.details'

    sale_form_id = fields.Many2one('sale.confirm.form', String="Delivery  Side Contact Persons Details")

    name = fields.Char("Name")
    birthday = fields.Date("Birthday")
    email = fields.Char("Email ID")
    designation = fields.Char("Designation")
    cell_no = fields.Char("Cell No/Ph No")