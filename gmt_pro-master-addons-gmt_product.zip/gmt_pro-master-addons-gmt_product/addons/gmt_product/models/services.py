from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz



class Service(models.Model):
    _name = 'services.services'
    _rec_name='seq_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    selectcustomers = fields.Many2one('res.partner', string='Select Customers', required=True,track_visibility='onchange',domain = "[('user_ids','=',False)]")
    productname = fields.Many2one('product.template', string="Product Name",track_visibility='onchange')
    date = fields.Datetime(string="Date&Time", default=lambda *a: datetime.now(),required=True,track_visibility='onchange')
    brand = fields.Many2one('brand.brand', string='Brand',track_visibility='onchange',related='productname.brand_name')
    
    # model_name = fields.Many2one("product.template.attribute.value", string='Model',track_visibility='onchange')
    product_id = fields.Many2one("product.product", string='Model',domain = "[('product_tmpl_id','=',productname)]")
    serialno = fields.Char(string='Serial No',track_visibility='onchange')
    priority = fields.Selection([('high', 'High'), ('medium', 'Medium'), ('low', 'Low')], string='Priority',required=True,track_visibility='onchange')
    natureofcomplaint = fields.Text(string='Nature Of Complaint',track_visibility='onchange')
    description = fields.Text(string='Description',track_visibility='onchange')

    amc_serial = fields.Many2one('amc.amc',string="Serial No",track_visibility='onchange')
    warranty_serial = fields.Many2one('warrenty.warrenty',string='Serial No',track_visibility='onchange')
    
    my_field_service1 = fields.Selection([('amc', "AMC"), ('non_amc', "Non-AMC"), ('warranty', "Warranty")],string="Service Type",track_visibility='onchange')
    my_fields_service2 = fields.Selection([('on_site_services', "On Site Services"), ('in_house_services', "In House Services")],string="Service Type",track_visibility='onchange')
    # attendee_ids = fields.Many2many('itemreceived.itemreceived', string="Item Recevied",track_visibility='onchange')
    # service_state = fields.Selection([('draft', 'Draft'), ('assigned', 'Assigned'),
    #                                 ('completed', 'Completed'), ('returned', 'Returned'),
    #                                 ('not_solved', 'Not solved')],
    #                                 string='Service Status')
    staged = fields.Many2one('kanban.staged', string="Staged",track_visibility='onchange',group_expand='expand_groups')
    inv_stage_identifier = fields.Boolean(string="Stage Identifier",track_visibility='onchange')
    users = fields.Many2one('res.users',string="Assigned User",track_visibility='onchange')
    product_price = fields.Float(string='Price',track_visibility='onchange')
    packagename = fields.Char(string="Package Name",track_visibility='onchange')
    invoice_count = fields.Integer(string='Invoice Count')
    seq_name = fields.Char('Service No')
    is_user_assign = fields.Boolean(string='User Assign',related='staged.is_user_assign')
    is_completed = fields.Boolean(string='Is Completed Stage',compute='change_stage',store=True)

    
    @api.depends('staged')
    def change_stage(self):
        if self.is_completed == True:
            raise ValidationError(_("You can't perform that move !"))
        self.is_completed = self.staged.is_completed

        
    def button_applicant_backend(self):
           return {
           'name': ('Invoice Count'),
           'view_mode': 'tree,form', 
           'res_model': 'account.move',
           'type': 'ir.actions.act_window', 
           'domain': [('invoice_line_ids.service_seq','=',self.seq_name)],
           }
    
    
    @api.model
    def create(self,vals):
        result = super(Service, self).create(vals)
        result.seq_name= f"{'S'}{self.env['ir.sequence'].next_by_code('sequence.service')}"
        
        if result.staged:
            pass
        else:
            stage=self.env['kanban.staged'].search([],limit=1)
            result.staged=stage
        
        return result
        
        
    @api.model
    def expand_groups(self, states, domain, order):
        return self.env['kanban.staged'].search([])

    def complete(self):
        for rec in self:
            stage=self.env['kanban.staged'].search([('is_completed','=',True)],limit=1)
            rec.staged = stage.id
            
    @api.onchange('users')
    def _assigned_user(self):
        for rec in self:
            if rec.users:
                stage=self.env['kanban.staged'].search([('is_user_assign','=',True)],limit=1)
                rec.staged = stage.id


    def action_invoice_create_wizard(self):
        for rec in self:
            delivey_invoice = self.env['account.move'].create([
                {
                    'move_type': 'out_invoice',
                    'invoice_date': fields.Date.context_today(self),
                    'partner_id': rec.selectcustomers.id,
                    'currency_id': 20,
                    'amount_total': 1 * rec.product_price,
                    'l10n_in_gst_treatment':'consumer',
                    'invoice_line_ids': [
                        (0, None, {
                            'product_id': rec.product_id.id,
                            'name': 'Delivery Service',
                            'quantity': 1,
                            'price_unit': rec.product_price,
                            'price_subtotal': rec.product_price,
                            'brand': rec.brand,
                            # 'model':rec.model_name,
                            'number':rec.serialno,
                            'packagename':rec.packagename,
                            'service_seq':rec.seq_name,
                        }),
                    ],
                },
            ])
            
            account_orm=self.env['account.move'].search([('move_type','=','out_invoice'),('invoice_line_ids.service_seq','=',self.seq_name)])
            self.invoice_count = len(account_orm)

    # @api.onchange('productname')
    # def _onchange_productname(self):
    #     return {'domain': {'model_name': [('product_tmpl_id', '=', self.productname.id)]}}
    
    @api.onchange('selectcustomers','my_field_service1')
    def _domain_amc(self):
        for rec in self:
            return {'domain': {'amc_serial': [('name','=',rec.selectcustomers.id)]}}
    
    @api.onchange('amc_serial')
    def _onchange_amc_serial(self):
        # self.brand = self.amc_serial.brand
        self.productname = self.amc_serial.productname
        self.product_id = self.amc_serial.product_id
        self.serialno = self.amc_serial.number
        self.product_price = self.amc_serial.price
        self.packagename = self.amc_serial.packagename.packagename
    
    @api.onchange('selectcustomers','my_field_service1')
    def _onchange_sr_no(self):
        for rec in self:
            return {'domain':{'warranty_serial':[('name','=',rec.selectcustomers.id)]}}
    
    @api.onchange('warranty_serial')
    def _onchange_serial(self):
        # self.brand = self.warranty_serial.brand
        self.productname = self.warranty_serial.productname
        self.product_id = self.warranty_serial.product_id
        self.serialno = self.warranty_serial.number
        self.product_price = self.warranty_serial.price
        self.packagename = self.warranty_serial.packagenames.packagename
        

class SalonStages(models.Model):
    _name = 'kanban.staged'
    _rec_name = 'name'

    name = fields.Char(string="Name", required=True, translate=True)
    is_completed = fields.Boolean(string='Is Completed Stage')
    is_user_assign = fields.Boolean(string='User Assign')


class ProductProduct(models.Model):
    _inherit = 'product.template'

    brand_name = fields.Many2one('brand.brand', String="Brand")




