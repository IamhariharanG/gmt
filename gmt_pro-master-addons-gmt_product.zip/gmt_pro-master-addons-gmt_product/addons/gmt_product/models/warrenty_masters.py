from odoo import models, fields, api, exceptions
from openerp.exceptions import ValidationError
from datetime import datetime
import re
from dateutil.relativedelta import relativedelta
from datetime import datetime, date, timedelta
from odoo import models, fields, api, _
from odoo.exceptions import Warning, UserError
import pytz


class Warrentyadd(models.Model):
    _name = 'warrenty.package'
    _rec_name='packagename'

    productname=fields.Many2one('product.template',string="Product Name", required=True)
    productage=fields.Char(string="Product Age", required=True)
    packagename=fields.Char(string="Package Name", required=True,compute='_compute_packagename')
    gender = fields.Selection([('with_spare', 'With Spare'), ('with_out_spare', 'With Out Spare')], string='Package Type', required=True)
    preventive = fields.Integer(string='Preventive(onsite)Maintenance')
    breakdown = fields.Integer(string='Breakdown(InHouse)')
    totalmaintenance=fields.Float(string='Total Maintenance',compute='_compute_total')
    price = fields.Integer(string='Price')

    @api.depends('preventive','breakdown')
    def _compute_total(self):
        for record in self:
            record.totalmaintenance = record.preventive + record.breakdown

    @api.depends('packagename','productage','gender')
    def _compute_packagename(self):
        for record in self:
            record.packagename = (record.productname.name or '') + ' ' + (record.productage or '') + ' ' + (dict(self._fields['gender'].selection).get(record.gender) or '')


class Warrenty(models.Model):
    _name = 'warrenty.warrenty'
    _rec_name='number'

    name = fields.Many2one('res.partner',string='Customer Name', required=True,domain = "[('user_ids','=',False)]")
    brand = fields.Many2one('brand.brand',string='Brand')
    productcategory=fields.Many2one('product.category',string="Product Category")
    productname=fields.Many2one('product.template',string="Product Name",domain = "[('brand_name','=',brand)]")
    # model = fields.Many2one("product.template.attribute.value", string='Model', help='Select Model', ondelete='restrict',domain = "[('product_tmpl_id','=',productname)]")
    product_id = fields.Many2one("product.product", string='Model',domain = "[('product_tmpl_id','=',productname)]")
    number=fields.Char(string="Serial No")
    packagenames=fields.Many2one('warrenty.package',string='Package Name',domain = "[('productname','=',productname)]")
    preventive = fields.Integer(string='Preventive(onsite) Maintenance',compute='_compute_Preventive')
    breakdown = fields.Integer(string='Breakdown(InHouse)',compute='_compute_Breakdown')
    totalmaintenance=fields.Float(string='Total Maintenance',compute='_compute_total')
    price = fields.Integer(string='Price')


    @api.depends('preventive', 'breakdown')
    def _compute_total(self):
        for record in self:
            record.totalmaintenance = record.preventive + record.breakdown

    @api.depends('preventive')
    def _compute_Preventive(self):
        for record in self:
            record.preventive = record.packagenames.preventive

    @api.depends('breakdown')
    def _compute_Breakdown(self):
        for record in self:
            record.breakdown = record.packagenames.breakdown

    @api.onchange('packagenames')
    def _onchange_packagename(self):
        self.breakdown = self.packagenames.breakdown
        self.preventive = self.packagenames.preventive
        self.price = self.packagenames.price

    # @api.onchange('productname')
    # def _onchange_productname(self):
    #     return {'domain': {'model': [('product_tmpl_id','=',self.productname.id)]}}
    
    # @api.onchange('productname')
    # def _onchange_productdomain(self):
    #     return {'domain': {'packagenames': [('productname','=',self.productname.id)]}}